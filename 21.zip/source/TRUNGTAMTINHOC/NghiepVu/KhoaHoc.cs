﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace TRUNGTAMTINHOC.NghiepVu
{
    class KhoaHoc
    {
        private string makhoahoc;
        private string tenkhoahoc;
        private string mota;
        private int sonhp;
        private int sohp;
        private string ccvb;

        public string MaKhoaHoc { get => makhoahoc; set => makhoahoc = value; }
        public string TenKhoaHoc { get => tenkhoahoc; set => tenkhoahoc = value; }
        public string MoTa { get => mota; set => mota = value; }
        public int SoNHP { get => sonhp; set => sonhp = value; }
        public int SoHP { get => sohp; set => sohp = value; }
        public string CCVB { get => ccvb; set => ccvb = value; }

        



    }
}
