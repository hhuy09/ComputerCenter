﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace TRUNGTAMTINHOC.NghiepVu
{
    class NhomHocPhan
    {
        private string manhomhp;
        private string khoahoc;
        private string ccvb;
        private string tennhomhp;
        private int sohocphan;

        public string MaNHP { get => manhomhp; set => manhomhp = value; }
        public string KhoaHoc { get => khoahoc; set => khoahoc = value; }
        public string CCVB { get => ccvb; set => ccvb = value; }
        public string TenNHP { get => tennhomhp; set => tennhomhp = value; }
        public int SoHocPhan { get => sohocphan; set => sohocphan = value; }

        //public NhomHocPhan()
        //{

        //}



    }
}
