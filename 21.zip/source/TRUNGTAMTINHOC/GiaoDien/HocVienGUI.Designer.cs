﻿
namespace TRUNGTAMTINHOC
{
    partial class LopHoc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LopHoc));
            this.button_DKKHCD = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label5 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button_DangXuat = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button_TTHV = new System.Windows.Forms.Button();
            this.button_DKHP = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // button_DKKHCD
            // 
            this.button_DKKHCD.BackColor = System.Drawing.Color.White;
            this.button_DKKHCD.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_DKKHCD.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_DKKHCD.Image = global::TRUNGTAMTINHOC.Properties.Resources.regiscourse;
            this.button_DKKHCD.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button_DKKHCD.Location = new System.Drawing.Point(73, 244);
            this.button_DKKHCD.Name = "button_DKKHCD";
            this.button_DKKHCD.Size = new System.Drawing.Size(277, 106);
            this.button_DKKHCD.TabIndex = 36;
            this.button_DKKHCD.Text = "Đăng ký khóa học - chuyên đề";
            this.button_DKKHCD.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button_DKKHCD.UseVisualStyleBackColor = false;
            this.button_DKKHCD.Click += new System.EventHandler(this.button2_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.BackgroundImage = global::TRUNGTAMTINHOC.Properties.Resources.icon;
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pictureBox2.ErrorImage = null;
            this.pictureBox2.Location = new System.Drawing.Point(425, 98);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(139, 140);
            this.pictureBox2.TabIndex = 35;
            this.pictureBox2.TabStop = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(13, 34);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(140, 19);
            this.label5.TabIndex = 34;
            this.label5.Text = "Học viên trung tâm";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.BackgroundImage = global::TRUNGTAMTINHOC.Properties.Resources.admin;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pictureBox1.InitialImage = null;
            this.pictureBox1.Location = new System.Drawing.Point(807, 8);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(39, 36);
            this.pictureBox1.TabIndex = 33;
            this.pictureBox1.TabStop = false;
            // 
            // button_DangXuat
            // 
            this.button_DangXuat.BackColor = System.Drawing.Color.Transparent;
            this.button_DangXuat.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button_DangXuat.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_DangXuat.Image = global::TRUNGTAMTINHOC.Properties.Resources.logout;
            this.button_DangXuat.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_DangXuat.Location = new System.Drawing.Point(852, 8);
            this.button_DangXuat.Name = "button_DangXuat";
            this.button_DangXuat.Size = new System.Drawing.Size(120, 20);
            this.button_DangXuat.TabIndex = 32;
            this.button_DangXuat.Text = "Đăng xuất";
            this.button_DangXuat.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_DangXuat.UseVisualStyleBackColor = false;
            this.button_DangXuat.Click += new System.EventHandler(this.button1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(849, 31);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 15);
            this.label2.TabIndex = 31;
            this.label2.Text = "TenHV";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Cambria", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(411, 25);
            this.label1.TabIndex = 30;
            this.label1.Text = "HỆ THỐNG QUẢN LÝ TRUNG TÂM TIN HỌC";
            // 
            // button_TTHV
            // 
            this.button_TTHV.BackColor = System.Drawing.Color.White;
            this.button_TTHV.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_TTHV.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_TTHV.Image = global::TRUNGTAMTINHOC.Properties.Resources.info;
            this.button_TTHV.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button_TTHV.Location = new System.Drawing.Point(639, 244);
            this.button_TTHV.Name = "button_TTHV";
            this.button_TTHV.Size = new System.Drawing.Size(277, 106);
            this.button_TTHV.TabIndex = 39;
            this.button_TTHV.Text = "Thông tin học viên";
            this.button_TTHV.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button_TTHV.UseVisualStyleBackColor = false;
            this.button_TTHV.Click += new System.EventHandler(this.button3_Click);
            // 
            // button_DKHP
            // 
            this.button_DKHP.BackColor = System.Drawing.Color.White;
            this.button_DKHP.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_DKHP.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_DKHP.Image = global::TRUNGTAMTINHOC.Properties.Resources.registsub;
            this.button_DKHP.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button_DKHP.Location = new System.Drawing.Point(356, 244);
            this.button_DKHP.Name = "button_DKHP";
            this.button_DKHP.Size = new System.Drawing.Size(277, 106);
            this.button_DKHP.TabIndex = 38;
            this.button_DKHP.Text = "Đăng ký học phần";
            this.button_DKHP.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button_DKHP.UseVisualStyleBackColor = false;
            this.button_DKHP.Click += new System.EventHandler(this.button4_Click);
            // 
            // LopHoc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::TRUNGTAMTINHOC.Properties.Resources.background;
            this.ClientSize = new System.Drawing.Size(984, 561);
            this.Controls.Add(this.button_TTHV);
            this.Controls.Add(this.button_DKHP);
            this.Controls.Add(this.button_DKKHCD);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button_DangXuat);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "LopHoc";
            this.Text = "Học viên trung tâm";
            this.Load += new System.EventHandler(this.HocVien_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_DKKHCD;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button_DangXuat;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button_TTHV;
        private System.Windows.Forms.Button button_DKHP;
    }
}