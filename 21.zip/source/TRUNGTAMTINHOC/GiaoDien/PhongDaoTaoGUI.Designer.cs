﻿
namespace TRUNGTAMTINHOC
{
    partial class PhongDaoTao
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PhongDaoTao));
            this.label1 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btn_DangxuatPDT = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.btn_loadPDT = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Cambria", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(411, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "HỆ THỐNG QUẢN LÝ TRUNG TÂM TIN HỌC";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(13, 34);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(163, 19);
            this.label5.TabIndex = 27;
            this.label5.Text = "Bộ phận phòng đào tạo";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.BackgroundImage = global::TRUNGTAMTINHOC.Properties.Resources.admin;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pictureBox1.InitialImage = null;
            this.pictureBox1.Location = new System.Drawing.Point(823, 9);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(39, 36);
            this.pictureBox1.TabIndex = 26;
            this.pictureBox1.TabStop = false;
            // 
            // btn_DangxuatPDT
            // 
            this.btn_DangxuatPDT.BackColor = System.Drawing.Color.Transparent;
            this.btn_DangxuatPDT.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn_DangxuatPDT.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_DangxuatPDT.Image = global::TRUNGTAMTINHOC.Properties.Resources.logout;
            this.btn_DangxuatPDT.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_DangxuatPDT.Location = new System.Drawing.Point(872, 9);
            this.btn_DangxuatPDT.Margin = new System.Windows.Forms.Padding(4);
            this.btn_DangxuatPDT.Name = "btn_DangxuatPDT";
            this.btn_DangxuatPDT.Size = new System.Drawing.Size(99, 20);
            this.btn_DangxuatPDT.TabIndex = 25;
            this.btn_DangxuatPDT.Text = "Đăng xuất ";
            this.btn_DangxuatPDT.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_DangxuatPDT.UseVisualStyleBackColor = false;
            this.btn_DangxuatPDT.Click += new System.EventHandler(this.btn_DangxuatPDT_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(869, 33);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 15);
            this.label2.TabIndex = 24;
            this.label2.Text = "TenNV";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.BackgroundImage = global::TRUNGTAMTINHOC.Properties.Resources.icon;
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pictureBox2.ErrorImage = null;
            this.pictureBox2.Location = new System.Drawing.Point(410, 106);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(139, 140);
            this.pictureBox2.TabIndex = 28;
            this.pictureBox2.TabStop = false;
            // 
            // btn_loadPDT
            // 
            this.btn_loadPDT.BackColor = System.Drawing.Color.White;
            this.btn_loadPDT.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_loadPDT.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_loadPDT.Image = global::TRUNGTAMTINHOC.Properties.Resources.certificate;
            this.btn_loadPDT.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_loadPDT.Location = new System.Drawing.Point(327, 254);
            this.btn_loadPDT.Margin = new System.Windows.Forms.Padding(4);
            this.btn_loadPDT.Name = "btn_loadPDT";
            this.btn_loadPDT.Size = new System.Drawing.Size(302, 99);
            this.btn_loadPDT.TabIndex = 29;
            this.btn_loadPDT.Text = "Quản lý chứng chỉ - văn bằng";
            this.btn_loadPDT.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_loadPDT.UseVisualStyleBackColor = false;
            this.btn_loadPDT.Click += new System.EventHandler(this.btn_loadPDT_Click);
            // 
            // PhongDaoTao
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::TRUNGTAMTINHOC.Properties.Resources.background;
            this.ClientSize = new System.Drawing.Size(984, 561);
            this.Controls.Add(this.btn_loadPDT);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btn_DangxuatPDT);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "PhongDaoTao";
            this.Text = "Nhân viên phòng đào tạo";
            this.Load += new System.EventHandler(this.PhongDaoTao_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btn_DangxuatPDT;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button btn_loadPDT;
    }
}